#include <stdlib.h>

// This function returns the length of a string
int ft_strlen(char *str)
{
    int len = 0;
    while (str[len])
        len++;
    return (len);
}

// This function returns the index of a character in a string, or -1 if not found
int ft_index_of(char c, char *str)
{
    int i = 0;
    while (str[i])
    {
        if (str[i] == c)
            return (i);
        i++;
    }
    return (-1);
}

// This function converts a number from one base to another
char *ft_convert_base(char *nbr, char *base_from, char *base_to)
{
    int base_from_len = ft_strlen(base_from); // The length of the base from which the number is converted
    int base_to_len = ft_strlen(base_to); // The length of the base to which the number is converted
    int nbr_len = ft_strlen(nbr); // The length of the number to be converted
    int nbr_sign = 1; // The sign of the number to be converted
    int nbr_dec = 0; // The decimal value of the number to be converted
    int nbr_dec_len = 0; // The length of the decimal value of the number to be converted
    char *nbr_base_to; // The pointer to the converted number
    int i = 0; // A loop variable

    // Check if the bases are valid (at least 2 characters and no duplicates)
    if (base_from_len < 2 || base_to_len < 2)
        return (NULL);
    for (i = 0; i < base_from_len; i++)
        if (ft_index_of(base_from[i], base_from + i + 1) != -1)
            return (NULL);
    for (i = 0; i < base_to_len; i++)
        if (ft_index_of(base_to[i], base_to + i + 1) != -1)
            return (NULL);

    // Convert the number from the base from to decimal
    i = 0;
    while (nbr[i] == ' ' || nbr[i] == '\t' || nbr[i] == '\n' || nbr[i] == '\v' || nbr[i] == '\f' || nbr[i] == '\r')
        i++; // Skip the whitespaces
    while (nbr[i] == '+' || nbr[i] == '-')
    {
        if (nbr[i] == '-')
            nbr_sign *= -1; // Determine the sign of the number
        i++;
    }
    while (nbr[i])
    {
        int index = ft_index_of(nbr[i], base_from); // Get the index of the current digit in the base from
        if (index == -1)
            break; // Stop if the digit is not valid
        nbr_dec = nbr_dec * base_from_len + index; // Multiply the previous decimal value by the base from and add the current digit
        i++;
    }

    // Convert the decimal value to the base to
    if (nbr_dec == 0) // If the decimal value is zero, return "0" in the base to
        return ("0");
    while (nbr_dec > 0) // Count the length of the decimal value in the base to
    {
        nbr_dec /= base_to_len;
        nbr_dec_len++;
    }
    nbr_base_to = malloc(sizeof(char) * (nbr_dec_len + 1 + (nbr_sign < 0))); // Allocate memory for the converted number (+1 for '\0' and +1 for '-')
    if (!nbr_base_to) // Return NULL if allocation fails
        return (NULL);
    nbr_base_to[nbr_dec_len + (nbr_sign < 0)] = '\0'; // Add the null terminator at the end of the string
    if (nbr_sign < 0) // Add a '-' at the beginning of the string if the number is negative
        nbr_base_to[0] = '-';
    
    nbr_dec = nbr_sign * nbr_dec; // Restore the decimal value with its sign
    while (nbr_dec > 0) // Convert each digit from decimal to the base to and store it in reverse order in the string
    {
        nbr_base_to[--nbr_dec_len + (nbr_sign < 0)] = base_to[nbr_dec % base_to_len];
        nbr_dec /= base_to_len;
    }

    return (nbr_base_to); // Return the pointer to the converted number
}
